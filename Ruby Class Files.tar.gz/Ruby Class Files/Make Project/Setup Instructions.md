Kevin's Make Project Helper
----------------------------

This file was an add on to the class that produced a project quickly ready for
you to build your code into.  It is raw, and given to you without any warranty
what so ever.  Easy licensing rules... you open, you own it, its yours... enjoy

Setup
=====

There are two files here:

 - A bash script in the bin folder

 - A default Rakefile to us

Copy the *mkproj* file from the bin folder, to a directory in your path.  I
installed it into ${HOME}/bin.  My Arch system does not include this in my path
by default, so I needed to add *PATH=${HOME}/bin:$PATH* to my ~/.bashrc file.
Some distros such as Ubuntu will already include this in your path.

Next, copy the .Rakefile to your home directory.

If you don't want your Rakefile in your home directory, simply change the bash
script to pull it from a place of your choosing.

Usage
=====

To use this program, simply cd to the directory where you want the project to
appear under, and enter:

    $ mkproj MyProjectName

What to Expect
==============

The script will create a directory under whatever directory you called this
from, called MyProjectName.  It will copy the rake file from you home directory
to the MyProjectName folder, and call *rake setup*

 - Rake's setup task will create a bin, lib, doc, log, etc folders for you.

 - A Gemfile will be created with all the gems listed for the base app

 - Bundler update will be run to insure your Ruby/Gem invironment is complete

 - A file will be created in the bin folder with common tasks

 - A file will be created in the bin folder with a first exe program with the
   same name as the project

 - A cucumber environment will be setup

 - A cucumber feature file, and corresponding steps file will be created for
   new exe file.

 - A Man page will be generated for the new exe file

 - The RSpec environment will be set up in your lib folder

Program Prerequisites
=====================

In order to run this script, you need the following already set up:

 - Ruby (obviously)

 - Bundler

 - Rake

***Enjoy***

