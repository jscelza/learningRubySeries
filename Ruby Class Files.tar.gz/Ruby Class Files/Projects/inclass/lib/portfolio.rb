class Portfolio
   attr_reader :stocks

   def initialize(data)
      @stocks = Stocks.new(data["Stocks"])
   end
end

class Stocks
   attr_reader :tickers

   def initialize(stock_hash)
      @tickers = Hash.new

      stock_hash.keys.each {|ticker| @tickers[ticker] = Stock.new(stock_hash[ticker])}
   end
end

class Stock
   attr_reader :name
   attr_reader :transactions

   def initialize(data)
      @name = data["Name"]
      @transactions = Transactions.new(data["Transactions"])
   end
end

class Transactions
   attr_reader :items

   def initialize (transaction_list)
      @items = Array.new

      transaction_list.each do |transaction|
         case transaction["Action"]
         when "Purchase"
            @items << Purchase.new(transaction)
         when "Dividend"
            @items << Dividend.new(transaction)
         when "Stock Split"
            @items << StockSplit.new(transaction)
         else
            raise "Unknown type of transaction found in portfolio file"
         end
      end
   end
end

class Transaction
   attr_accessor :action
   attr_accessor :date

   def initialize(data)
      @action = data["Action"]
      @date = data["Date"]
   end
end

class Purchase < Transaction
   attr_accessor :shares
   attr_accessor :price

   def initialize(data)
      super(data)
      @shares = data["Shares"]
      @price = data["Price"]
   end
end

class Dividend < Transaction
   attr_accessor :amount

   def initialize(data)
      super(data)
      @amount =  data["Amount"]
   end
end

class StockSplit < Transaction
   attr_accessor :newNumber
   attr_accessor :oldNumber

   def initialize(data)
      super(data)
      @newNumber = data["NewNumber"]
      @oldNumber = data["OldNumber"]
   end
end



{
    "Stocks": {
        "MSFT": {
           "Name": "Microsoft",
           "Transactions": [
               { "Action": "Dividend", "Date": "11-14-2006", "Amount":"0.10" },
               { "Action": "Dividend", "Date": "8-15-2006", "Amount":"0.09" },
               { "Action": "Dividend", "Date": "5-15-2006", "Amount":"0.09" },
               { "Action": "Dividend", "Date": "2-15-2006", "Amount":"0.09" },
               { "Action": "Dividend", "Date": "11-15-2005", "Amount":"0.08" },
               { "Action": "Dividend", "Date": "8-15-2005", "Amount":"0.08" },
               { "Action": "Dividend", "Date": "5-16-2005", "Amount":"0.08" },
               { "Action": "Dividend", "Date": "2-15-2005", "Amount":"0.08" },
               { "Action": "Dividend", "Date": "11-15-2004", "Amount":"3.08" },
               { "Action": "Dividend", "Date": "8-23-2004", "Amount":"0.08" },
               { "Action": "Dividend", "Date": "10-15-2003", "Amount":"0.16" },
               { "Action": "Dividend", "Date": "2-19-2003", "Amount":"0.08" },
               { "Action": "Stock Split", "Date": "2-18-2003", "NewNumber":"2", "OldNumber":"1" },
               { "Action": "Stock Split", "Date": "3-29-1999", "NewNumber":"2", "OldNumber":"1" },
               { "Action": "Stock Split", "Date": "2-23-1998", "NewNumber":"2", "OldNumber":"1" },
               { "Action": "Stock Split", "Date": "12-9-1996", "NewNumber":"2", "OldNumber":"1" },
               { "Action": "Stock Split", "Date": "5-23-1994", "NewNumber":"2", "OldNumber":"1" },
               { "Action": "Stock Split", "Date": "6-15-1992", "NewNumber":"3", "OldNumber":"2" }
           ]
        },
        "AAPL": {
           "Name": "Apple",
           "Transactions": [
               { "Action": "Purchase", "Date":   "1-2-02", "Shares":"500", "Price": "23.30" },
               { "Action": "Dividend", "Date": "2-5-2015", "Amount":"0.47" },
               { "Action": "Dividend", "Date": "11-6-2014", "Amount":"0.47" },
               { "Action": "Dividend", "Date": "8-7-2014", "Amount":"0.47" },
               { "Action": "Dividend", "Date": "5-8-2014", "Amount":"0.47" },
               { "Action": "Dividend", "Date": "2-6-2014", "Amount":"0.43571" },
               { "Action": "Dividend", "Date": "11-6-2013", "Amount":"0.43571" },
               { "Action": "Dividend", "Date": "8-8-2013", "Amount":"0.43571" },
               { "Action": "Dividend", "Date": "5-9-2013", "Amount":"0.43571" },
               { "Action": "Dividend", "Date": "2-7-2013", "Amount":"0.37857" },
               { "Action": "Dividend", "Date": "11-7-2012", "Amount":"0.37857" },
               { "Action": "Dividend", "Date": "8-9-2012", "Amount":"0.37857" },
               { "Action": "Stock Split", "Date": "6-9-2014", "NewNumber":"7", "OldNumber":"1" },
               { "Action": "Stock Split", "Date": "2-28-2005", "NewNumber":"2", "OldNumber":"1" }
           ]
        },
        "GOOGL": {
           "Name": "Google",
           "Transactions": [
               { "Action": "Purchase", "Date": "9-1-2004", "Shares":"750", "Price": "100.25" }
           ]
        }
    }
}
