require 'aruba/cucumber'

$LOAD_PATH.unshift(File.dirname(__FILE__) + '/../../lib')
