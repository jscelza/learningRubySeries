Given(/^a pending event for inclass$/) do
   pending # express the regexp above with the code you wish you had
end
