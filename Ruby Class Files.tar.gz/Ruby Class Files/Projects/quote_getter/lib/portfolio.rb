
require 'rest-client'
require 'json'
require 'date'

class Portfolio
   attr_reader :filename
   attr_reader :stocklist
   attr_reader :portfolio_hash

   def initialize(diskfile = nil)
      @filename = diskfile
      @stocklist = nil
      @dirty = false
      @updated = false

      readfile(diskfile) unless diskfile.nil?
   end

   def readfile(diskfile = nil)
      raise "#{diskfile} is not a valid profile file" if diskfile.nil?
      raise "#{diskfile} not found" unless File.exist?(diskfile)

      @portfolio_hash = JSON.parse(File.open(diskfile).read)
      @stocklist = StockList.new(@portfolio_hash["Stocks"])
      @filename = diskfile
   end

   def updateFromWeb(url)
      params= {
         :params => {
            :s => @stocklist.symbols.join("+"),
            :f => "p"
         }
      }

      @stocklist.updateCurrentPrices(RestClient.get(url, params).split("\r\n"))
   end

   def dirty?
      @dirty
   end

   def updated?
      @updated
   end
end

class StockList
   attr_reader :stocks

   def initialize(stock_list)
      @stocks = stock_list.collect {|stock| Stock.new(stock)}
   end

   def each (&block)
      @stocks.each {|stock| yield stock }
   end

   def symbols
      @stocks.collect {|stock| stock.ticker}
   end

   def updateCurrentPrices(quoteArray)
      @stocks.each {|s| s.quote = quoteArray.shift.to_f unless quoteArray.empty?}
   end
end

class Stock
   attr_reader :ticker
   attr_reader :name
   attr_reader :transactions
   attr_accessor :quote

   def initialize(stock_def)
      (@ticker, stock_definition) = stock_def
      @name = stock_definition["Name"]
      @transactions = TransactionList.new(stock_definition["Transactions"])
   end
end

class TransactionList
   attr_reader :transactions

   def initialize(transaction_list)
      @transactions = transaction_list.collect do |trans|
      case trans["Action"]
         when "Purchase"
            Purchase.new(trans)
         when "Dividend"
            Dividend.new(trans)
         when "Stock Split"
            Split.new(trans)
         else
            raise "Unknown Transaction Type: #{trans["Action"]}"
         end
      end
   end

   def each (&block)
      @transactions.each {|transaction| yield transaction}
   end

   def by_type(type)
      @transactions.select {|transaction| transaction.type == type }
   end
end

class Transaction
   def initialize(trans_def)
      @type = trans_def["Action"]
      @date = Date::strptime(trans_def["Date"], "%m-%d-%Y")
   end
end

class Purchase < Transaction
   attr_reader :type
   attr_reader :date
   attr_reader :shares
   attr_reader :price

   def initialize(purchase_def)
      super(purchase_def)
      @shares = purchase_def["Shares"].to_f
      @price = purchase_def["Price"].to_f
   end

   def to_s
      "Purchase of %d shares, at $%.2f per share, on %s... total cost of %.2f" % [@shares, @price, @date, @shares * @price]
   end
end

class Dividend < Transaction
   attr_reader :type
   attr_reader :date
   attr_reader :amount

   def initialize(dividend_def)
      super(dividend_def)
      @amount = dividend_def["Amount"]
   end

   def to_s
      "Received a divided of #{@amount} on #{@date}"
   end
end

class Split < Transaction
   attr_reader :type
   attr_reader :date
   attr_reader :oldamount
   attr_reader :newamount

   def initialize(split_def)
      super(split_def)
      @oldamount = split_def["OldNumber"].to_i
      @newamount = split_def["NewNumber"].to_i
   end

   def to_s
      "A Stock Split occured on #{@date}, we now have #{@newamount} for ever #{oldamount} we had before"
   end
end

